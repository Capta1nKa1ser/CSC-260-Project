﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Character_Creator
{
    class Race
    {
        public string raceSelected;
        public string raceInfo;

        public void RaceSelection()
        {
            if (raceSelected == "Dragonborn")
            {
                raceInfo = "Ability Score Increase" +
                    "\nYour Strength score increases by 2, and your Charisma score increases by 1." +
                    "\n\nAge" +
                    "\nYoung dragonborn grow quickly.They walk hours after hatching, attain the size and development of a 10 - year - old human child by the age of 3, and reach adulthood by 15.They live to be around 80." +
                    "\n\nAlignment" +
                    "\nDragonborn tend to extremes, making a conscious choice for one side or the other in the cosmic war between good and evil(represented by Bahamut and Tiamat, respectively).Most dragonborn are good, but those who side with Tiamat can be terrible villains." +
                    "\n\nSize" +
                    "\nDragonborn are taller and heavier than humans, standing well over 6 feet tall and averaging almost 250 pounds.Your size is Medium." +
                    "\n\nSpeed" +
                    "\nYour base walking speed is 30 feet." +
                    "\n\nDraconic Ancestry" +
                    "\nYou have draconic ancestry.Your breath weapon and damage resistance are determined by the dragon type." +
                    "\n\nBreath Weapon" +
                    "\nYou can use your action to exhale destructive energy.Your draconic ancestry determines the size, shape, and damage type of the exhalation.When you use your breath weapon, each creature in the area of the exhalation must make a saving throw, the type of which is determined by your draconic ancestry.The DC for this saving throw equals 8 + your Constitution modifier + your proficiency bonus.A creature takes 2d6 damage on a failed save, and half as much damage on a successful one.The damage increases to 3d6 at 6th level, 4d6 at 11th level, and 5d6 at 16th level.After you use your breath weapon, you can’t use it again until you complete a short or long rest." +
                    "\n\nDamage Resistance" +
                    "\nYou have resistance to the damage type associated with your draconic ancestry." +
                    "\n\nLanguages" +
                    "\nYou can speak, read, and write Common and Draconic.Draconic is thought to be one of the oldest languages and is often used in the study of magic.The language sounds harsh to most other creatures and includes numerous hard consonants and sibilants.";
            }

            if (raceSelected == "Dwarf")
            {
                raceInfo = "";
            }

            if (raceSelected == "Elf")
            {
                raceInfo = "";
            }

            if (raceSelected == "Gnome")
            {
                raceInfo = "";
            }

            if (raceSelected == "Half-Elf")
            {
                raceInfo = "";
            }

            if (raceSelected == "Halfling")
            {
                raceInfo = "";
            }

            if (raceSelected == "Half-Orc")
            {
                raceInfo = "";
            }

            if (raceSelected == "Human")
            {
                raceInfo = "";
            }

            if (raceSelected == "Tiefling")
            {
                raceInfo = "";
            }
        }
    }
}
