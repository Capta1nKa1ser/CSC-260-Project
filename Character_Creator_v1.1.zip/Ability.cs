﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Character_Creator
{
    class Ability
    {
        public int str;
        public int dex;
        public int con;
        public int intl;
        public int wis;
        public int cha;
        public int strMod;
        public int dexMod;
        public int conMod;
        public int intMod;
        public int wisMod;
        public int chaMod;

        public Ability()
        {

        }

        public void CalcMod()
        {
            strMod = (str - 10) / 2;
            dexMod = (dex - 10) / 2;
            conMod = (con - 10) / 2;
            intMod = (intl - 10) / 2;
            wisMod = (wis - 10) / 2;
            chaMod = (cha - 10) / 2;
        }

    }
}
