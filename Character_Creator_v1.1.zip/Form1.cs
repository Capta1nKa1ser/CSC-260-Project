﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Character_Creator
{
    public partial class Form1 : Form
    {
        private Ability ability = new Ability();
        private Class playerClass = new Class();
        private Race playerRace = new Race();
        public bool error1 = false;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        public void generate(object sender, EventArgs e)
        {
            error1 = false;

            ability.str = Convert.ToInt32(strBox.Text);
            if (ability.str < 1 || ability.str > 20 && error1 == false)
            { error1 = true; }

            ability.dex = Convert.ToInt32(dexBox.Text);
            if (ability.dex < 1 || ability.dex > 20 && error1 == false)
            { error1 = true; }

            ability.con = Convert.ToInt32(conBox.Text);
            if (ability.con < 1 || ability.con > 20 && error1 == false)
            { error1 = true; }

            ability.intl = Convert.ToInt32(intBox.Text);
            if (ability.intl < 1 || ability.intl > 20 && error1 == false)
            { error1 = true; }

            ability.wis = Convert.ToInt32(wisBox.Text);
            if (ability.wis < 1 || ability.wis > 20 && error1 == false)
            { error1 = true; }

            ability.cha = Convert.ToInt32(chaBox.Text);
            if (ability.cha < 1 || ability.cha > 20 && error1 == false)
            { error1 = true; }

            if (error1 == true)
            {
                ErrorBox.Text = "Values entered into abilities, out of bounds!";
            }
            else
            {
                ability.CalcMod();
                StrMod.Text = ability.strMod.ToString();
                DexMod.Text = ability.dexMod.ToString();
                ConMod.Text = ability.conMod.ToString();
                IntMod.Text = ability.intMod.ToString();
                WisMod.Text = ability.wisMod.ToString();
                ChaMod.Text = ability.chaMod.ToString();
                AcroBox.Text = ability.dexMod.ToString();
                AnimBox.Text = ability.wisMod.ToString();
                ArcaBox.Text = ability.intMod.ToString();
                AthlBox.Text = ability.strMod.ToString();
                DeceBox.Text = ability.chaMod.ToString();
                HistBox.Text = ability.intMod.ToString();
                InsiBox.Text = ability.wisMod.ToString();
                IntiBox.Text = ability.chaMod.ToString();
                InveBox.Text = ability.intMod.ToString();
                MediBox.Text = ability.wisMod.ToString();
                NatuBox.Text = ability.intMod.ToString();
                PercBox.Text = ability.wisMod.ToString();
                PerfBox.Text = ability.chaMod.ToString();
                PersBox.Text = ability.chaMod.ToString();
                ReliBox.Text = ability.intMod.ToString();
                SleiBox.Text = ability.dexMod.ToString();
                SteaBox.Text = ability.dexMod.ToString();
                SurvBox.Text = ability.wisMod.ToString();

    //Return to this later

                if (classDropBox.SelectedItem.ToString() == null)
                {
                    ErrorBox.Text = "Select a class!";
                }
                else
                {
                    string classSelect = classDropBox.SelectedItem.ToString();
                    playerClass.classSelected = classSelect;
                    playerClass.classSelection();
                    ClassInfoBox.Text = playerClass.classInfo;
                }

                if (raceDropBox.SelectedItem.ToString() == null)
                {
                    ErrorBox.Text = "Select a race!";
                }
                else
                {
                    string raceSelect = raceDropBox.SelectedItem.ToString();
                    playerRace.raceSelected = raceSelect;
                    playerRace.RaceSelection();
                    RaceInfoBox.Text = playerRace.raceInfo;
                }

                string backgroundSelect = backDropBox.SelectedItem.ToString();
                if (backgroundSelect == "Acolyte")
                {
                    Acolyte acolyte = new Acolyte();
                    BackgroundInfoBox.Text = acolyte.desc;
                }
            }
        }
    }
}
