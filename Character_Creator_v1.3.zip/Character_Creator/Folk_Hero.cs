﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Character_Creator
{
    class Folk_Hero : Background
    {
        public Folk_Hero()
        {
            desc = "Skill Proficiencies: Animal Handling, Survival" +
                "\nTool Proficiencies: One type of artisan’s tools, vehicles (land)" +
                "\nEquipment: A set of artisan’s tools(one of your choice), a shovel, an iron pot, a set of common clothes, and a pouch containing 10 gp" +
                "\n\nFeature: Rustic Hospitality" +
                "\nSince you come from the ranks of the common folk, you fit in among them with ease. You can find a place to hide, rest, or recuperate among other commoners, unless you have shown yourself to be a danger to them.  They will shield you from the law or anyone else searching for you, though they will not risk their lives for you.";
        }
    }
}
