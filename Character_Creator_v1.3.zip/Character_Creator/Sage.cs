﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Character_Creator
{
    class Sage : Background
    {
        public Sage()
        {
            desc = "Skill Proficiencies: Arcana, History" +
                "\nLanguages: Two of your choice" +
                "\nEquipment: A bottle of black ink, a quill, a small knife, a letter from a dead colleague posing a question you have not yet been able to answer, a set of common clothes, and a pouch containing 10 gp" +
                "\n\nFeature: Researcher" +
                "\nWhen you attempt to learn or recall a piece of lore, if you do not know that information, you often know where and from whom you can obtain it.Usually, this information comes from a library, scriptorium, university, or a sage or other learned person or creature.  Your DM might rule that the knowledge you seek is secreted away in an almost inaccessible place, or that it simply cannot be found.  Unearthing the deepest secrets of the multiverse can require an adventure or even a whole campaign.";
        }
    }
}
