﻿namespace Character_Creator
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.Strength = new System.Windows.Forms.Label();
            this.Dexterity = new System.Windows.Forms.Label();
            this.Charisma = new System.Windows.Forms.Label();
            this.Wisdom = new System.Windows.Forms.Label();
            this.Intelligence = new System.Windows.Forms.Label();
            this.Constitution = new System.Windows.Forms.Label();
            this.raceDropBox = new System.Windows.Forms.ComboBox();
            this.Background = new System.Windows.Forms.Label();
            this.Race = new System.Windows.Forms.Label();
            this.Class = new System.Windows.Forms.Label();
            this.backDropBox = new System.Windows.Forms.ComboBox();
            this.classDropBox = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.StrMod = new System.Windows.Forms.TextBox();
            this.ChaMod = new System.Windows.Forms.TextBox();
            this.WisMod = new System.Windows.Forms.TextBox();
            this.IntMod = new System.Windows.Forms.TextBox();
            this.ConMod = new System.Windows.Forms.TextBox();
            this.DexMod = new System.Windows.Forms.TextBox();
            this.Acrobatics = new System.Windows.Forms.Label();
            this.Arcana = new System.Windows.Forms.Label();
            this.Animal_Handling = new System.Windows.Forms.Label();
            this.Deception = new System.Windows.Forms.Label();
            this.History = new System.Windows.Forms.Label();
            this.Athletics = new System.Windows.Forms.Label();
            this.Nature = new System.Windows.Forms.Label();
            this.Perception = new System.Windows.Forms.Label();
            this.Medicine = new System.Windows.Forms.Label();
            this.Intimidation = new System.Windows.Forms.Label();
            this.Investigation = new System.Windows.Forms.Label();
            this.Insight = new System.Windows.Forms.Label();
            this.Stealth = new System.Windows.Forms.Label();
            this.Survival = new System.Windows.Forms.Label();
            this.Sleight_of_Hand = new System.Windows.Forms.Label();
            this.Persuasion = new System.Windows.Forms.Label();
            this.Religion = new System.Windows.Forms.Label();
            this.Performance = new System.Windows.Forms.Label();
            this.AcroBox = new System.Windows.Forms.TextBox();
            this.AnimBox = new System.Windows.Forms.TextBox();
            this.AthlBox = new System.Windows.Forms.TextBox();
            this.ArcaBox = new System.Windows.Forms.TextBox();
            this.IntiBox = new System.Windows.Forms.TextBox();
            this.InsiBox = new System.Windows.Forms.TextBox();
            this.HistBox = new System.Windows.Forms.TextBox();
            this.DeceBox = new System.Windows.Forms.TextBox();
            this.SleiBox = new System.Windows.Forms.TextBox();
            this.ReliBox = new System.Windows.Forms.TextBox();
            this.PersBox = new System.Windows.Forms.TextBox();
            this.PerfBox = new System.Windows.Forms.TextBox();
            this.PercBox = new System.Windows.Forms.TextBox();
            this.NatuBox = new System.Windows.Forms.TextBox();
            this.MediBox = new System.Windows.Forms.TextBox();
            this.InveBox = new System.Windows.Forms.TextBox();
            this.SurvBox = new System.Windows.Forms.TextBox();
            this.SteaBox = new System.Windows.Forms.TextBox();
            this.label29 = new System.Windows.Forms.Label();
            this.label30 = new System.Windows.Forms.Label();
            this.ClassInfoBox = new System.Windows.Forms.RichTextBox();
            this.RaceInfoBox = new System.Windows.Forms.RichTextBox();
            this.BackgroundInfoBox = new System.Windows.Forms.RichTextBox();
            this.label31 = new System.Windows.Forms.Label();
            this.label32 = new System.Windows.Forms.Label();
            this.label33 = new System.Windows.Forms.Label();
            this.CreateButton = new System.Windows.Forms.Button();
            this.ErrorBox = new System.Windows.Forms.RichTextBox();
            this.strBox = new System.Windows.Forms.NumericUpDown();
            this.chaBox = new System.Windows.Forms.NumericUpDown();
            this.wisBox = new System.Windows.Forms.NumericUpDown();
            this.intBox = new System.Windows.Forms.NumericUpDown();
            this.conBox = new System.Windows.Forms.NumericUpDown();
            this.dexBox = new System.Windows.Forms.NumericUpDown();
            ((System.ComponentModel.ISupportInitialize)(this.strBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.wisBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.intBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.conBox)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dexBox)).BeginInit();
            this.SuspendLayout();
            // 
            // Strength
            // 
            this.Strength.AutoSize = true;
            this.Strength.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Strength.Location = new System.Drawing.Point(48, 51);
            this.Strength.Name = "Strength";
            this.Strength.Size = new System.Drawing.Size(80, 24);
            this.Strength.TabIndex = 1;
            this.Strength.Text = "Strength";
            // 
            // Dexterity
            // 
            this.Dexterity.AutoSize = true;
            this.Dexterity.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Dexterity.Location = new System.Drawing.Point(46, 86);
            this.Dexterity.Name = "Dexterity";
            this.Dexterity.Size = new System.Drawing.Size(82, 24);
            this.Dexterity.TabIndex = 2;
            this.Dexterity.Text = "Dexterity";
            // 
            // Charisma
            // 
            this.Charisma.AutoSize = true;
            this.Charisma.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Charisma.Location = new System.Drawing.Point(39, 226);
            this.Charisma.Name = "Charisma";
            this.Charisma.Size = new System.Drawing.Size(89, 24);
            this.Charisma.TabIndex = 3;
            this.Charisma.Text = "Charisma";
            // 
            // Wisdom
            // 
            this.Wisdom.AutoSize = true;
            this.Wisdom.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Wisdom.Location = new System.Drawing.Point(49, 191);
            this.Wisdom.Name = "Wisdom";
            this.Wisdom.Size = new System.Drawing.Size(79, 24);
            this.Wisdom.TabIndex = 4;
            this.Wisdom.Text = "Wisdom";
            // 
            // Intelligence
            // 
            this.Intelligence.AutoSize = true;
            this.Intelligence.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Intelligence.Location = new System.Drawing.Point(22, 156);
            this.Intelligence.Name = "Intelligence";
            this.Intelligence.Size = new System.Drawing.Size(106, 24);
            this.Intelligence.TabIndex = 5;
            this.Intelligence.Text = "Intelligence";
            // 
            // Constitution
            // 
            this.Constitution.AutoSize = true;
            this.Constitution.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Constitution.Location = new System.Drawing.Point(21, 121);
            this.Constitution.Name = "Constitution";
            this.Constitution.Size = new System.Drawing.Size(107, 24);
            this.Constitution.TabIndex = 6;
            this.Constitution.Text = "Constitution";
            // 
            // raceDropBox
            // 
            this.raceDropBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.raceDropBox.FormattingEnabled = true;
            this.raceDropBox.Items.AddRange(new object[] {
            "Dragonborn",
            "Dwarf",
            "Elf",
            "Gnome",
            "Half-Elf",
            "Halfling",
            "Half-Orc",
            "Human",
            "Tiefling"});
            this.raceDropBox.Location = new System.Drawing.Point(141, 322);
            this.raceDropBox.Name = "raceDropBox";
            this.raceDropBox.Size = new System.Drawing.Size(132, 32);
            this.raceDropBox.TabIndex = 13;
            // 
            // Background
            // 
            this.Background.AutoSize = true;
            this.Background.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Background.Location = new System.Drawing.Point(16, 363);
            this.Background.Name = "Background";
            this.Background.Size = new System.Drawing.Size(112, 24);
            this.Background.TabIndex = 16;
            this.Background.Text = "Background";
            // 
            // Race
            // 
            this.Race.AutoSize = true;
            this.Race.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Race.Location = new System.Drawing.Point(74, 325);
            this.Race.Name = "Race";
            this.Race.Size = new System.Drawing.Size(54, 24);
            this.Race.TabIndex = 17;
            this.Race.Text = "Race";
            // 
            // Class
            // 
            this.Class.AutoSize = true;
            this.Class.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Class.Location = new System.Drawing.Point(73, 287);
            this.Class.Name = "Class";
            this.Class.Size = new System.Drawing.Size(55, 24);
            this.Class.TabIndex = 18;
            this.Class.Text = "Class";
            // 
            // backDropBox
            // 
            this.backDropBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.backDropBox.FormattingEnabled = true;
            this.backDropBox.Items.AddRange(new object[] {
            "Acolyte",
            "Criminal/Spy",
            "Folk Hero",
            "Noble",
            "Sage",
            "Soldier"});
            this.backDropBox.Location = new System.Drawing.Point(141, 360);
            this.backDropBox.Name = "backDropBox";
            this.backDropBox.Size = new System.Drawing.Size(132, 32);
            this.backDropBox.TabIndex = 24;
            // 
            // classDropBox
            // 
            this.classDropBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.classDropBox.FormattingEnabled = true;
            this.classDropBox.Items.AddRange(new object[] {
            "Barbarian",
            "Bard",
            "Cleric",
            "Druid",
            "Fighter",
            "Monk",
            "Paladin",
            "Ranger",
            "Rogue",
            "Sorcerer",
            "Warlock",
            "Wizard"});
            this.classDropBox.Location = new System.Drawing.Point(141, 284);
            this.classDropBox.Name = "classDropBox";
            this.classDropBox.Size = new System.Drawing.Size(132, 32);
            this.classDropBox.TabIndex = 25;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label10.Location = new System.Drawing.Point(257, 21);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(140, 24);
            this.label10.TabIndex = 26;
            this.label10.Text = "Ability Modifiers";
            // 
            // StrMod
            // 
            this.StrMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.StrMod.Location = new System.Drawing.Point(271, 48);
            this.StrMod.Name = "StrMod";
            this.StrMod.ReadOnly = true;
            this.StrMod.Size = new System.Drawing.Size(100, 29);
            this.StrMod.TabIndex = 27;
            this.StrMod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ChaMod
            // 
            this.ChaMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ChaMod.Location = new System.Drawing.Point(271, 223);
            this.ChaMod.Name = "ChaMod";
            this.ChaMod.ReadOnly = true;
            this.ChaMod.Size = new System.Drawing.Size(100, 29);
            this.ChaMod.TabIndex = 28;
            this.ChaMod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // WisMod
            // 
            this.WisMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.WisMod.Location = new System.Drawing.Point(271, 188);
            this.WisMod.Name = "WisMod";
            this.WisMod.ReadOnly = true;
            this.WisMod.Size = new System.Drawing.Size(100, 29);
            this.WisMod.TabIndex = 29;
            this.WisMod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // IntMod
            // 
            this.IntMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IntMod.Location = new System.Drawing.Point(271, 153);
            this.IntMod.Name = "IntMod";
            this.IntMod.ReadOnly = true;
            this.IntMod.Size = new System.Drawing.Size(100, 29);
            this.IntMod.TabIndex = 30;
            this.IntMod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ConMod
            // 
            this.ConMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ConMod.Location = new System.Drawing.Point(271, 118);
            this.ConMod.Name = "ConMod";
            this.ConMod.ReadOnly = true;
            this.ConMod.Size = new System.Drawing.Size(100, 29);
            this.ConMod.TabIndex = 31;
            this.ConMod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DexMod
            // 
            this.DexMod.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DexMod.Location = new System.Drawing.Point(271, 83);
            this.DexMod.Name = "DexMod";
            this.DexMod.ReadOnly = true;
            this.DexMod.Size = new System.Drawing.Size(100, 29);
            this.DexMod.TabIndex = 32;
            this.DexMod.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // Acrobatics
            // 
            this.Acrobatics.AutoSize = true;
            this.Acrobatics.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Acrobatics.Location = new System.Drawing.Point(418, 51);
            this.Acrobatics.Name = "Acrobatics";
            this.Acrobatics.Size = new System.Drawing.Size(78, 18);
            this.Acrobatics.TabIndex = 33;
            this.Acrobatics.Text = "Acrobatics";
            // 
            // Arcana
            // 
            this.Arcana.AutoSize = true;
            this.Arcana.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Arcana.Location = new System.Drawing.Point(442, 111);
            this.Arcana.Name = "Arcana";
            this.Arcana.Size = new System.Drawing.Size(54, 18);
            this.Arcana.TabIndex = 49;
            this.Arcana.Text = "Arcana";
            // 
            // Animal_Handling
            // 
            this.Animal_Handling.AutoSize = true;
            this.Animal_Handling.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Animal_Handling.Location = new System.Drawing.Point(383, 81);
            this.Animal_Handling.Name = "Animal_Handling";
            this.Animal_Handling.Size = new System.Drawing.Size(113, 18);
            this.Animal_Handling.TabIndex = 50;
            this.Animal_Handling.Text = "Animal Handling";
            // 
            // Deception
            // 
            this.Deception.AutoSize = true;
            this.Deception.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Deception.Location = new System.Drawing.Point(421, 171);
            this.Deception.Name = "Deception";
            this.Deception.Size = new System.Drawing.Size(75, 18);
            this.Deception.TabIndex = 53;
            this.Deception.Text = "Deception";
            // 
            // History
            // 
            this.History.AutoSize = true;
            this.History.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.History.Location = new System.Drawing.Point(441, 201);
            this.History.Name = "History";
            this.History.Size = new System.Drawing.Size(55, 18);
            this.History.TabIndex = 52;
            this.History.Text = "History";
            // 
            // Athletics
            // 
            this.Athletics.AutoSize = true;
            this.Athletics.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Athletics.Location = new System.Drawing.Point(433, 141);
            this.Athletics.Name = "Athletics";
            this.Athletics.Size = new System.Drawing.Size(63, 18);
            this.Athletics.TabIndex = 51;
            this.Athletics.Text = "Athletics";
            // 
            // Nature
            // 
            this.Nature.AutoSize = true;
            this.Nature.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Nature.Location = new System.Drawing.Point(444, 351);
            this.Nature.Name = "Nature";
            this.Nature.Size = new System.Drawing.Size(52, 18);
            this.Nature.TabIndex = 59;
            this.Nature.Text = "Nature";
            // 
            // Perception
            // 
            this.Perception.AutoSize = true;
            this.Perception.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Perception.Location = new System.Drawing.Point(417, 381);
            this.Perception.Name = "Perception";
            this.Perception.Size = new System.Drawing.Size(79, 18);
            this.Perception.TabIndex = 58;
            this.Perception.Text = "Perception";
            // 
            // Medicine
            // 
            this.Medicine.AutoSize = true;
            this.Medicine.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Medicine.Location = new System.Drawing.Point(429, 321);
            this.Medicine.Name = "Medicine";
            this.Medicine.Size = new System.Drawing.Size(67, 18);
            this.Medicine.TabIndex = 57;
            this.Medicine.Text = "Medicine";
            // 
            // Intimidation
            // 
            this.Intimidation.AutoSize = true;
            this.Intimidation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Intimidation.Location = new System.Drawing.Point(414, 261);
            this.Intimidation.Name = "Intimidation";
            this.Intimidation.Size = new System.Drawing.Size(82, 18);
            this.Intimidation.TabIndex = 56;
            this.Intimidation.Text = "Intimidation";
            // 
            // Investigation
            // 
            this.Investigation.AutoSize = true;
            this.Investigation.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Investigation.Location = new System.Drawing.Point(407, 291);
            this.Investigation.Name = "Investigation";
            this.Investigation.Size = new System.Drawing.Size(89, 18);
            this.Investigation.TabIndex = 55;
            this.Investigation.Text = "Investigation";
            // 
            // Insight
            // 
            this.Insight.AutoSize = true;
            this.Insight.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Insight.Location = new System.Drawing.Point(446, 231);
            this.Insight.Name = "Insight";
            this.Insight.Size = new System.Drawing.Size(50, 18);
            this.Insight.TabIndex = 54;
            this.Insight.Text = "Insight";
            // 
            // Stealth
            // 
            this.Stealth.AutoSize = true;
            this.Stealth.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Stealth.Location = new System.Drawing.Point(443, 531);
            this.Stealth.Name = "Stealth";
            this.Stealth.Size = new System.Drawing.Size(53, 18);
            this.Stealth.TabIndex = 65;
            this.Stealth.Text = "Stealth";
            // 
            // Survival
            // 
            this.Survival.AutoSize = true;
            this.Survival.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Survival.Location = new System.Drawing.Point(437, 561);
            this.Survival.Name = "Survival";
            this.Survival.Size = new System.Drawing.Size(59, 18);
            this.Survival.TabIndex = 64;
            this.Survival.Text = "Survival";
            // 
            // Sleight_of_Hand
            // 
            this.Sleight_of_Hand.AutoSize = true;
            this.Sleight_of_Hand.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Sleight_of_Hand.Location = new System.Drawing.Point(388, 501);
            this.Sleight_of_Hand.Name = "Sleight_of_Hand";
            this.Sleight_of_Hand.Size = new System.Drawing.Size(108, 18);
            this.Sleight_of_Hand.TabIndex = 63;
            this.Sleight_of_Hand.Text = "Sleight of Hand";
            // 
            // Persuasion
            // 
            this.Persuasion.AutoSize = true;
            this.Persuasion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Persuasion.Location = new System.Drawing.Point(413, 441);
            this.Persuasion.Name = "Persuasion";
            this.Persuasion.Size = new System.Drawing.Size(83, 18);
            this.Persuasion.TabIndex = 62;
            this.Persuasion.Text = "Persuasion";
            // 
            // Religion
            // 
            this.Religion.AutoSize = true;
            this.Religion.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Religion.Location = new System.Drawing.Point(435, 471);
            this.Religion.Name = "Religion";
            this.Religion.Size = new System.Drawing.Size(61, 18);
            this.Religion.TabIndex = 61;
            this.Religion.Text = "Religion";
            // 
            // Performance
            // 
            this.Performance.AutoSize = true;
            this.Performance.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Performance.Location = new System.Drawing.Point(402, 411);
            this.Performance.Name = "Performance";
            this.Performance.Size = new System.Drawing.Size(94, 18);
            this.Performance.TabIndex = 60;
            this.Performance.Text = "Performance";
            // 
            // AcroBox
            // 
            this.AcroBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AcroBox.Location = new System.Drawing.Point(502, 48);
            this.AcroBox.Name = "AcroBox";
            this.AcroBox.ReadOnly = true;
            this.AcroBox.Size = new System.Drawing.Size(100, 24);
            this.AcroBox.TabIndex = 66;
            this.AcroBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AnimBox
            // 
            this.AnimBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AnimBox.Location = new System.Drawing.Point(502, 78);
            this.AnimBox.Name = "AnimBox";
            this.AnimBox.ReadOnly = true;
            this.AnimBox.Size = new System.Drawing.Size(100, 24);
            this.AnimBox.TabIndex = 67;
            this.AnimBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // AthlBox
            // 
            this.AthlBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AthlBox.Location = new System.Drawing.Point(502, 138);
            this.AthlBox.Name = "AthlBox";
            this.AthlBox.ReadOnly = true;
            this.AthlBox.Size = new System.Drawing.Size(100, 24);
            this.AthlBox.TabIndex = 69;
            this.AthlBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ArcaBox
            // 
            this.ArcaBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ArcaBox.Location = new System.Drawing.Point(502, 108);
            this.ArcaBox.Name = "ArcaBox";
            this.ArcaBox.ReadOnly = true;
            this.ArcaBox.Size = new System.Drawing.Size(100, 24);
            this.ArcaBox.TabIndex = 68;
            this.ArcaBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // IntiBox
            // 
            this.IntiBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IntiBox.Location = new System.Drawing.Point(502, 258);
            this.IntiBox.Name = "IntiBox";
            this.IntiBox.ReadOnly = true;
            this.IntiBox.Size = new System.Drawing.Size(100, 24);
            this.IntiBox.TabIndex = 73;
            this.IntiBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InsiBox
            // 
            this.InsiBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InsiBox.Location = new System.Drawing.Point(502, 228);
            this.InsiBox.Name = "InsiBox";
            this.InsiBox.ReadOnly = true;
            this.InsiBox.Size = new System.Drawing.Size(100, 24);
            this.InsiBox.TabIndex = 72;
            this.InsiBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // HistBox
            // 
            this.HistBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.HistBox.Location = new System.Drawing.Point(502, 198);
            this.HistBox.Name = "HistBox";
            this.HistBox.ReadOnly = true;
            this.HistBox.Size = new System.Drawing.Size(100, 24);
            this.HistBox.TabIndex = 71;
            this.HistBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // DeceBox
            // 
            this.DeceBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeceBox.Location = new System.Drawing.Point(502, 168);
            this.DeceBox.Name = "DeceBox";
            this.DeceBox.ReadOnly = true;
            this.DeceBox.Size = new System.Drawing.Size(100, 24);
            this.DeceBox.TabIndex = 70;
            this.DeceBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SleiBox
            // 
            this.SleiBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SleiBox.Location = new System.Drawing.Point(502, 498);
            this.SleiBox.Name = "SleiBox";
            this.SleiBox.ReadOnly = true;
            this.SleiBox.Size = new System.Drawing.Size(100, 24);
            this.SleiBox.TabIndex = 81;
            this.SleiBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // ReliBox
            // 
            this.ReliBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ReliBox.Location = new System.Drawing.Point(502, 468);
            this.ReliBox.Name = "ReliBox";
            this.ReliBox.ReadOnly = true;
            this.ReliBox.Size = new System.Drawing.Size(100, 24);
            this.ReliBox.TabIndex = 80;
            this.ReliBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PersBox
            // 
            this.PersBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PersBox.Location = new System.Drawing.Point(502, 438);
            this.PersBox.Name = "PersBox";
            this.PersBox.ReadOnly = true;
            this.PersBox.Size = new System.Drawing.Size(100, 24);
            this.PersBox.TabIndex = 79;
            this.PersBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PerfBox
            // 
            this.PerfBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PerfBox.Location = new System.Drawing.Point(502, 408);
            this.PerfBox.Name = "PerfBox";
            this.PerfBox.ReadOnly = true;
            this.PerfBox.Size = new System.Drawing.Size(100, 24);
            this.PerfBox.TabIndex = 78;
            this.PerfBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // PercBox
            // 
            this.PercBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PercBox.Location = new System.Drawing.Point(502, 378);
            this.PercBox.Name = "PercBox";
            this.PercBox.ReadOnly = true;
            this.PercBox.Size = new System.Drawing.Size(100, 24);
            this.PercBox.TabIndex = 77;
            this.PercBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // NatuBox
            // 
            this.NatuBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NatuBox.Location = new System.Drawing.Point(502, 348);
            this.NatuBox.Name = "NatuBox";
            this.NatuBox.ReadOnly = true;
            this.NatuBox.Size = new System.Drawing.Size(100, 24);
            this.NatuBox.TabIndex = 76;
            this.NatuBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // MediBox
            // 
            this.MediBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MediBox.Location = new System.Drawing.Point(502, 318);
            this.MediBox.Name = "MediBox";
            this.MediBox.ReadOnly = true;
            this.MediBox.Size = new System.Drawing.Size(100, 24);
            this.MediBox.TabIndex = 75;
            this.MediBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // InveBox
            // 
            this.InveBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InveBox.Location = new System.Drawing.Point(502, 288);
            this.InveBox.Name = "InveBox";
            this.InveBox.ReadOnly = true;
            this.InveBox.Size = new System.Drawing.Size(100, 24);
            this.InveBox.TabIndex = 74;
            this.InveBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SurvBox
            // 
            this.SurvBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SurvBox.Location = new System.Drawing.Point(502, 558);
            this.SurvBox.Name = "SurvBox";
            this.SurvBox.ReadOnly = true;
            this.SurvBox.Size = new System.Drawing.Size(100, 24);
            this.SurvBox.TabIndex = 83;
            this.SurvBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // SteaBox
            // 
            this.SteaBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SteaBox.Location = new System.Drawing.Point(502, 528);
            this.SteaBox.Name = "SteaBox";
            this.SteaBox.ReadOnly = true;
            this.SteaBox.Size = new System.Drawing.Size(100, 24);
            this.SteaBox.TabIndex = 82;
            this.SteaBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label29
            // 
            this.label29.AutoSize = true;
            this.label29.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label29.Location = new System.Drawing.Point(165, 21);
            this.label29.Name = "label29";
            this.label29.Size = new System.Drawing.Size(70, 24);
            this.label29.TabIndex = 84;
            this.label29.Text = "Abilties";
            // 
            // label30
            // 
            this.label30.AutoSize = true;
            this.label30.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label30.Location = new System.Drawing.Point(525, 21);
            this.label30.Name = "label30";
            this.label30.Size = new System.Drawing.Size(52, 24);
            this.label30.TabIndex = 85;
            this.label30.Text = "Skills";
            // 
            // ClassInfoBox
            // 
            this.ClassInfoBox.Location = new System.Drawing.Point(622, 48);
            this.ClassInfoBox.Name = "ClassInfoBox";
            this.ClassInfoBox.ReadOnly = true;
            this.ClassInfoBox.Size = new System.Drawing.Size(187, 534);
            this.ClassInfoBox.TabIndex = 86;
            this.ClassInfoBox.Text = "";
            // 
            // RaceInfoBox
            // 
            this.RaceInfoBox.Location = new System.Drawing.Point(815, 48);
            this.RaceInfoBox.Name = "RaceInfoBox";
            this.RaceInfoBox.ReadOnly = true;
            this.RaceInfoBox.Size = new System.Drawing.Size(187, 534);
            this.RaceInfoBox.TabIndex = 87;
            this.RaceInfoBox.Text = "";
            // 
            // BackgroundInfoBox
            // 
            this.BackgroundInfoBox.Location = new System.Drawing.Point(1008, 48);
            this.BackgroundInfoBox.Name = "BackgroundInfoBox";
            this.BackgroundInfoBox.ReadOnly = true;
            this.BackgroundInfoBox.Size = new System.Drawing.Size(187, 534);
            this.BackgroundInfoBox.TabIndex = 88;
            this.BackgroundInfoBox.Text = "";
            // 
            // label31
            // 
            this.label31.AutoSize = true;
            this.label31.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label31.Location = new System.Drawing.Point(1030, 21);
            this.label31.Name = "label31";
            this.label31.Size = new System.Drawing.Size(147, 24);
            this.label31.TabIndex = 89;
            this.label31.Text = "Background Info";
            // 
            // label32
            // 
            this.label32.AutoSize = true;
            this.label32.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label32.Location = new System.Drawing.Point(861, 21);
            this.label32.Name = "label32";
            this.label32.Size = new System.Drawing.Size(89, 24);
            this.label32.TabIndex = 90;
            this.label32.Text = "Race Info";
            // 
            // label33
            // 
            this.label33.AutoSize = true;
            this.label33.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label33.Location = new System.Drawing.Point(666, 21);
            this.label33.Name = "label33";
            this.label33.Size = new System.Drawing.Size(90, 24);
            this.label33.TabIndex = 91;
            this.label33.Text = "Class Info";
            // 
            // CreateButton
            // 
            this.CreateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreateButton.Location = new System.Drawing.Point(141, 398);
            this.CreateButton.Name = "CreateButton";
            this.CreateButton.Size = new System.Drawing.Size(132, 33);
            this.CreateButton.TabIndex = 92;
            this.CreateButton.Text = "Create";
            this.CreateButton.UseVisualStyleBackColor = true;
            this.CreateButton.Click += new System.EventHandler(this.generate);
            // 
            // ErrorBox
            // 
            this.ErrorBox.Location = new System.Drawing.Point(43, 441);
            this.ErrorBox.Name = "ErrorBox";
            this.ErrorBox.ReadOnly = true;
            this.ErrorBox.Size = new System.Drawing.Size(228, 138);
            this.ErrorBox.TabIndex = 93;
            this.ErrorBox.Text = "";
            // 
            // strBox
            // 
            this.strBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.strBox.Location = new System.Drawing.Point(141, 48);
            this.strBox.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.strBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.strBox.Name = "strBox";
            this.strBox.ReadOnly = true;
            this.strBox.Size = new System.Drawing.Size(117, 29);
            this.strBox.TabIndex = 94;
            this.strBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.strBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // chaBox
            // 
            this.chaBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.chaBox.Location = new System.Drawing.Point(141, 223);
            this.chaBox.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.chaBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.chaBox.Name = "chaBox";
            this.chaBox.ReadOnly = true;
            this.chaBox.Size = new System.Drawing.Size(117, 29);
            this.chaBox.TabIndex = 95;
            this.chaBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.chaBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // wisBox
            // 
            this.wisBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.wisBox.Location = new System.Drawing.Point(141, 188);
            this.wisBox.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.wisBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.wisBox.Name = "wisBox";
            this.wisBox.ReadOnly = true;
            this.wisBox.Size = new System.Drawing.Size(117, 29);
            this.wisBox.TabIndex = 96;
            this.wisBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.wisBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // intBox
            // 
            this.intBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.intBox.Location = new System.Drawing.Point(141, 153);
            this.intBox.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.intBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.intBox.Name = "intBox";
            this.intBox.ReadOnly = true;
            this.intBox.Size = new System.Drawing.Size(117, 29);
            this.intBox.TabIndex = 97;
            this.intBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.intBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // conBox
            // 
            this.conBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.conBox.Location = new System.Drawing.Point(141, 118);
            this.conBox.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.conBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.conBox.Name = "conBox";
            this.conBox.ReadOnly = true;
            this.conBox.Size = new System.Drawing.Size(117, 29);
            this.conBox.TabIndex = 98;
            this.conBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.conBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // dexBox
            // 
            this.dexBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dexBox.Location = new System.Drawing.Point(141, 83);
            this.dexBox.Maximum = new decimal(new int[] {
            20,
            0,
            0,
            0});
            this.dexBox.Minimum = new decimal(new int[] {
            1,
            0,
            0,
            0});
            this.dexBox.Name = "dexBox";
            this.dexBox.ReadOnly = true;
            this.dexBox.Size = new System.Drawing.Size(117, 29);
            this.dexBox.TabIndex = 99;
            this.dexBox.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.dexBox.Value = new decimal(new int[] {
            10,
            0,
            0,
            0});
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1213, 600);
            this.Controls.Add(this.dexBox);
            this.Controls.Add(this.conBox);
            this.Controls.Add(this.intBox);
            this.Controls.Add(this.wisBox);
            this.Controls.Add(this.chaBox);
            this.Controls.Add(this.strBox);
            this.Controls.Add(this.ErrorBox);
            this.Controls.Add(this.CreateButton);
            this.Controls.Add(this.label33);
            this.Controls.Add(this.label32);
            this.Controls.Add(this.label31);
            this.Controls.Add(this.BackgroundInfoBox);
            this.Controls.Add(this.RaceInfoBox);
            this.Controls.Add(this.ClassInfoBox);
            this.Controls.Add(this.label30);
            this.Controls.Add(this.label29);
            this.Controls.Add(this.SurvBox);
            this.Controls.Add(this.SteaBox);
            this.Controls.Add(this.SleiBox);
            this.Controls.Add(this.ReliBox);
            this.Controls.Add(this.PersBox);
            this.Controls.Add(this.PerfBox);
            this.Controls.Add(this.PercBox);
            this.Controls.Add(this.NatuBox);
            this.Controls.Add(this.MediBox);
            this.Controls.Add(this.InveBox);
            this.Controls.Add(this.IntiBox);
            this.Controls.Add(this.InsiBox);
            this.Controls.Add(this.HistBox);
            this.Controls.Add(this.DeceBox);
            this.Controls.Add(this.AthlBox);
            this.Controls.Add(this.ArcaBox);
            this.Controls.Add(this.AnimBox);
            this.Controls.Add(this.AcroBox);
            this.Controls.Add(this.Stealth);
            this.Controls.Add(this.Survival);
            this.Controls.Add(this.Sleight_of_Hand);
            this.Controls.Add(this.Persuasion);
            this.Controls.Add(this.Religion);
            this.Controls.Add(this.Performance);
            this.Controls.Add(this.Nature);
            this.Controls.Add(this.Perception);
            this.Controls.Add(this.Medicine);
            this.Controls.Add(this.Intimidation);
            this.Controls.Add(this.Investigation);
            this.Controls.Add(this.Insight);
            this.Controls.Add(this.Deception);
            this.Controls.Add(this.History);
            this.Controls.Add(this.Athletics);
            this.Controls.Add(this.Animal_Handling);
            this.Controls.Add(this.Arcana);
            this.Controls.Add(this.Acrobatics);
            this.Controls.Add(this.DexMod);
            this.Controls.Add(this.ConMod);
            this.Controls.Add(this.IntMod);
            this.Controls.Add(this.WisMod);
            this.Controls.Add(this.ChaMod);
            this.Controls.Add(this.StrMod);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.classDropBox);
            this.Controls.Add(this.backDropBox);
            this.Controls.Add(this.Class);
            this.Controls.Add(this.Race);
            this.Controls.Add(this.Background);
            this.Controls.Add(this.raceDropBox);
            this.Controls.Add(this.Constitution);
            this.Controls.Add(this.Intelligence);
            this.Controls.Add(this.Wisdom);
            this.Controls.Add(this.Charisma);
            this.Controls.Add(this.Dexterity);
            this.Controls.Add(this.Strength);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "D&D Character Creator Assistant";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.strBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.chaBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.wisBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.intBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.conBox)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dexBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label Strength;
        private System.Windows.Forms.Label Dexterity;
        private System.Windows.Forms.Label Charisma;
        private System.Windows.Forms.Label Wisdom;
        private System.Windows.Forms.Label Intelligence;
        private System.Windows.Forms.Label Constitution;
        private System.Windows.Forms.ComboBox raceDropBox;
        private System.Windows.Forms.Label Background;
        private System.Windows.Forms.Label Race;
        private System.Windows.Forms.Label Class;
        private System.Windows.Forms.ComboBox backDropBox;
        private System.Windows.Forms.ComboBox classDropBox;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox StrMod;
        private System.Windows.Forms.TextBox ChaMod;
        private System.Windows.Forms.TextBox WisMod;
        private System.Windows.Forms.TextBox IntMod;
        private System.Windows.Forms.TextBox ConMod;
        private System.Windows.Forms.TextBox DexMod;
        private System.Windows.Forms.Label Acrobatics;
        private System.Windows.Forms.Label Arcana;
        private System.Windows.Forms.Label Animal_Handling;
        private System.Windows.Forms.Label Deception;
        private System.Windows.Forms.Label History;
        private System.Windows.Forms.Label Athletics;
        private System.Windows.Forms.Label Nature;
        private System.Windows.Forms.Label Perception;
        private System.Windows.Forms.Label Medicine;
        private System.Windows.Forms.Label Intimidation;
        private System.Windows.Forms.Label Investigation;
        private System.Windows.Forms.Label Insight;
        private System.Windows.Forms.Label Stealth;
        private System.Windows.Forms.Label Survival;
        private System.Windows.Forms.Label Sleight_of_Hand;
        private System.Windows.Forms.Label Persuasion;
        private System.Windows.Forms.Label Religion;
        private System.Windows.Forms.Label Performance;
        private System.Windows.Forms.TextBox AcroBox;
        private System.Windows.Forms.TextBox AnimBox;
        private System.Windows.Forms.TextBox AthlBox;
        private System.Windows.Forms.TextBox ArcaBox;
        private System.Windows.Forms.TextBox IntiBox;
        private System.Windows.Forms.TextBox InsiBox;
        private System.Windows.Forms.TextBox HistBox;
        private System.Windows.Forms.TextBox DeceBox;
        private System.Windows.Forms.TextBox SleiBox;
        private System.Windows.Forms.TextBox ReliBox;
        private System.Windows.Forms.TextBox PersBox;
        private System.Windows.Forms.TextBox PerfBox;
        private System.Windows.Forms.TextBox PercBox;
        private System.Windows.Forms.TextBox NatuBox;
        private System.Windows.Forms.TextBox MediBox;
        private System.Windows.Forms.TextBox InveBox;
        private System.Windows.Forms.TextBox SurvBox;
        private System.Windows.Forms.TextBox SteaBox;
        private System.Windows.Forms.Label label29;
        private System.Windows.Forms.Label label30;
        private System.Windows.Forms.RichTextBox ClassInfoBox;
        private System.Windows.Forms.RichTextBox RaceInfoBox;
        private System.Windows.Forms.RichTextBox BackgroundInfoBox;
        private System.Windows.Forms.Label label31;
        private System.Windows.Forms.Label label32;
        private System.Windows.Forms.Label label33;
        private System.Windows.Forms.Button CreateButton;
        private System.Windows.Forms.RichTextBox ErrorBox;
        private System.Windows.Forms.NumericUpDown strBox;
        private System.Windows.Forms.NumericUpDown chaBox;
        private System.Windows.Forms.NumericUpDown wisBox;
        private System.Windows.Forms.NumericUpDown intBox;
        private System.Windows.Forms.NumericUpDown conBox;
        private System.Windows.Forms.NumericUpDown dexBox;
    }
}

