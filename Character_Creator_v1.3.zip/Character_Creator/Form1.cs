﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Character_Creator
{
    public partial class Form1 : Form
    {
        private Ability ability = new Ability();
        private Race playerRace = new Race();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        //Generate Level 1 Character Info
        public void generate(object sender, EventArgs e)
        {
            //Ability Scores
            ability.str = Convert.ToInt32(strBox.Value);
            ability.dex = Convert.ToInt32(dexBox.Value);
            ability.con = Convert.ToInt32(conBox.Value);
            ability.intl = Convert.ToInt32(intBox.Value);
            ability.wis = Convert.ToInt32(wisBox.Value);
            ability.cha = Convert.ToInt32(chaBox.Value);

            //Skill Scores
            ability.CalcMod();
            StrMod.Text = ability.strMod.ToString();
            DexMod.Text = ability.dexMod.ToString();
            ConMod.Text = ability.conMod.ToString();
            IntMod.Text = ability.intMod.ToString();
            WisMod.Text = ability.wisMod.ToString();
            ChaMod.Text = ability.chaMod.ToString();
            AcroBox.Text = ability.dexMod.ToString();
            AnimBox.Text = ability.wisMod.ToString();
            ArcaBox.Text = ability.intMod.ToString();
            AthlBox.Text = ability.strMod.ToString();
            DeceBox.Text = ability.chaMod.ToString();
            HistBox.Text = ability.intMod.ToString();
            InsiBox.Text = ability.wisMod.ToString();
            IntiBox.Text = ability.chaMod.ToString();
            InveBox.Text = ability.intMod.ToString();
            MediBox.Text = ability.wisMod.ToString();
            NatuBox.Text = ability.intMod.ToString();
            PercBox.Text = ability.wisMod.ToString();
            PerfBox.Text = ability.chaMod.ToString();
            PersBox.Text = ability.chaMod.ToString();
            ReliBox.Text = ability.intMod.ToString();
            SleiBox.Text = ability.dexMod.ToString();
            SteaBox.Text = ability.dexMod.ToString();
            SurvBox.Text = ability.wisMod.ToString();

            //Class Select
            Class playerClass = new Class(classDropBox.Text);
            if (classDropBox.SelectedItem == null)
            {
                ErrorBox.Text = "Select a class!";
            }
            else
            {
                playerClass.classSelection();
                ClassInfoBox.Text = playerClass.classInfo;
            }

            //Race Select
            if (raceDropBox.SelectedItem == null)
            {
                ErrorBox.Text = "Select a race!";
            }
            else
            {
                string raceSelect = raceDropBox.SelectedItem.ToString();
                playerRace.raceSelected = raceSelect;
                playerRace.RaceSelection();
                RaceInfoBox.Text = playerRace.raceInfo;
            }

            //Background Select
            if (backDropBox.SelectedItem == null)
            {
                ErrorBox.Text = "Select a background!";
            }
            else
            { 
                string backgroundSelect = backDropBox.SelectedItem.ToString();
                if (backgroundSelect == "Acolyte")
                {
                    Acolyte acolyte = new Acolyte();
                    BackgroundInfoBox.Text = acolyte.desc;
                }
                if (backgroundSelect == "Criminal/Spy")
                {
                    Criminal_Spy criminal_Spy = new Criminal_Spy();
                    BackgroundInfoBox.Text = criminal_Spy.desc;
                }
                if (backgroundSelect == "Folk Hero")
                {
                    Folk_Hero folk_Hero = new Folk_Hero();
                    BackgroundInfoBox.Text = folk_Hero.desc;
                }
                if (backgroundSelect == "Noble")
                {
                    Noble noble = new Noble();
                    BackgroundInfoBox.Text = noble.desc;
                }
                if (backgroundSelect == "Sage")
                {
                    Sage sage = new Sage();
                    BackgroundInfoBox.Text = sage.desc;
                }
                if (backgroundSelect == "Soldier")
                {
                    Soldier soldier = new Soldier();
                    BackgroundInfoBox.Text = soldier.desc;
                }

            }            
        }
    }
}
