﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Character_Creator
{
    class Ability
    {
        public int str;
        public int dex;
        public int con;
        public int intl;
        public int wis;
        public int cha;
        public int strMod;
        public int dexMod;
        public int conMod;
        public int intMod;
        public int wisMod;
        public int chaMod;

        public Ability()
        {

        }

        //Ability Mod Calculators
        public void CalcMod()
        {
            //Strength Mod Calculation
            if (str < 10)
            {
                if (str % 2 != 0)
                {
                    strMod = ((str - 10) / 2) - 1;
                }
                else
                {
                    strMod = (str - 10) / 2;
                }
            }
            else
            {
                strMod = (str - 10) / 2;
            }

            //Dexterity Mod Calculation
            if (dex < 10)
            {
                if (dex % 2 != 0)
                {
                    dexMod = ((dex - 10) / 2) - 1;
                }
                else
                {
                    dexMod = (dex - 10) / 2;
                }
            }
            else
            {
                dexMod = (dex - 10) / 2;
            }

            //Constitution Mod Calculation
            if (con < 10)
            {
                if (con % 2 != 0)
                {
                    conMod = ((con - 10) / 2) - 1;
                }
                else
                {
                    conMod = (con - 10) / 2;
                }
            }
            else
            {
                conMod = (con - 10) / 2;
            }

            //Intelligence Mod Calculation
            if (intl < 10)
            {
                if (intl % 2 != 0)
                {
                    intMod = ((intl - 10) / 2) - 1;
                }
                else
                {
                    intMod = (intl - 10) / 2;
                }
            }
            else
            {
                intMod = (intl - 10) / 2;
            }

            //Wisdom Mod Calculation
            if (wis < 10)
            {
                if (wis % 2 != 0)
                {
                    wisMod = ((wis - 10) / 2) - 1;
                }
                else
                {
                    wisMod = (wis - 10) / 2;
                }
            }
            else
            {
                wisMod = (wis - 10) / 2;
            }

            //Charisma Mod Calculation
            if (cha < 10)
            {
                if (cha % 2 != 0)
                {
                    chaMod = ((cha - 10) / 2) - 1;
                }
                else
                {
                    chaMod = (cha - 10) / 2;
                }
            }
            else
            {
                chaMod = (cha - 10) / 2;
            }
        }

    }
}
