﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Character_Creator
{
    class Noble : Background
    {
        public Noble()
        {
            desc = "Skill Proficiencies: History, Persuasion" +
                "\nTool Proficiencies: One type of gaming set" +
                "\nLanguages: One of your choice" +
                "\nEquipment: A set of fine clothes, a signet ring, a scroll of pedigree, and a purse containing 25 gp"+
                "\n\nFeature: Position of Privilege" +
                "\nThanks to your noble birth, people are inclined to think the best of you.  You are welcome in high society, and people assume you have the right to be wherever you are.  The common folk make every effort to accommodate you and avoid your displeasure, and other people of high birth treat you as a member of the same social sphere.  You can secure an audience with a local noble if you need to.";
        }
    }
}
