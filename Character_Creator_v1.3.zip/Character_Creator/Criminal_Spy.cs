﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Character_Creator
{
    class Criminal_Spy : Background
    {
        public Criminal_Spy()
        {
            desc = "Skill Proficiencies: Deception, Stealth" +
                "\nTool Proficiencies: One type of gaming set, thieves’ tools" +
                "\nEquipment: A crowbar, a set of dark common clothes including a hood, and a pouch containing 15 gp" +
                "\n\nFeature: Criminal Contact" +
                "\nYou have a reliable and trustworthy contact who acts as your liaison to a network of other criminals.  You know how to get messages to and from your contact, even over great distances; specifically, you know the local messengers, corrupt caravan masters, and seedy sailors who can deliver messages for you.";
        }
    }
}
