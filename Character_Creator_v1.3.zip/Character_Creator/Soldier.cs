﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Character_Creator
{
    class Soldier : Background
    {
        public Soldier()
        {
            desc = "Skill Proficiencies: Athletics, Intimidation" +
                "\nTool Proficiencies: One type of gaming set, vehicles(land)" +
                "\nEquipment: An insignia of rank, a trophy taken from a fallen enemy(a dagger, broken blade, or piece of a banner), a set of bone dice or deck of cards, a set of common clothes, and a pouch containing 10 gp"+
                "\n\nFeature: Military Rank" +
                "\nYou have a military rank from your career as a soldier.Soldiers loyal to your former military organization still recognize your authority and influence, and they defer to you if they are of a lower rank.You can invoke your rank to exert influence over other soldiers and requisition simple equipment or horses for temporary use. You can also usually gain access to friendly military encampments and fortresses where your rank is recognized.";
        }
    }
}
