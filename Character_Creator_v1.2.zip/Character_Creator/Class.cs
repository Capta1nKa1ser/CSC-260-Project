﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Character_Creator
{
    class Class
    {
        public string classSelected;
        public string classInfo;

        public void classSelection()
        {
            if (classSelected == "Barbarian")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d12 per barbarian level" +
                    "\nHit Points at 1st Level: 12 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d12(or 7) + your Constitution modifier per barbarian level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: Light armor, medium armor, shields" +
                    "\nWeapons: Simple weapons, martial weapons" +
                    "\nTools: None" +
                    "\nSaving Throws: Strength, Constitution" +
                    "\nSkills: Choose two from Animal Handling, Athletics, Intimidation, Nature, Perception, and Survival" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)a greataxe or(b) any martial melee weapon" +
                    "\n-(a) two handaxes or(b) any simple weapon" +
                    "\n-An explorer’s pack and four javelins" +
                    "\n\nRage" +
                    "\nIn battle, you fight with primal ferocity. On your turn, you can enter a rage as a bonus action." +
                    "\nWhile raging, you gain the following benefits if you aren’t wearing heavy armor:" +
                    "\nYou have advantage on Strength checks and Strength saving throws." +
                    "\nWhen you make a melee weapon attack using Strength, you gain a bonus to the damage roll that increases as you gain levels as a barbarian, as shown in the Rage Damage column of the Barbarian table." +
                    "\nYou have resistance to bludgeoning, piercing, and slashing damage." +
                    "\nIf you are able to cast spells, you can’t cast them or concentrate on them while raging." +
                    "\nYour rage lasts for 1 minute.It ends early if you are knocked unconscious or if your turn ends and you haven’t attacked a hostile creature since your last turn or taken damage since then. You can also end your rage on your turn as a bonus action." +
                    "\nOnce you have raged the number of times shown for your barbarian level in the Rages column of the Barbarian table, you must finish a long rest before you can rage again." +
                    "\n\nUnarmored Defense" +
                    "\nWhile you are not wearing any armor, your Armor Class equals 10 + your Dexterity modifier + your Constitution modifier. You can use a shield and still gain this benefit.";        
            }

            if (classSelected == "Bard")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d8 per bard level" +
                    "\nHit Points at 1st Level: 8 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d8(or 5) + your Constitution modifier per bard level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: Light armor" +
                    "\nWeapons: Simple weapons, hand crossbows, longswords, rapiers, shortswords" +
                    "\nTools: Three musical instruments of your choice" +
                    "\nSaving Throws: Dexterity, Charisma" +
                    "\nSkills: Choose any three" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)a rapier, (b)a longsword, or(c) any simple weapon" +
                    "\n-(a) a diplomat’s pack or(b) an entertainer’s pack" +
                    "\n-(a) a lute or(b) any other musical instrument" +
                    "\n-Leather armor and a dagger" +
                    "\n\nSpellcasting" +
                    "\nYou have learned to untangle and reshape the fabric of reality in harmony with your wishes and music. Your spells are part of your vast repertoire, magic that you can tune to different situations.See Spells Rules for the general rules of spellcasting and the Spells Listing for the bard spell list." +
                    "\n\nCantrips" +
                    "\nYou know two cantrips of your choice from the bard spell list.You learn additional bard cantrips of your choice at higher levels, as shown in the Cantrips Known column of the Bard table." +
                    "\n\nSpell Slots" +
                    "\nThe Bard table shows how many spell slots you have to cast your bard spells of 1st level and higher.To cast one of these spells, you must expend a slot of the spell’s level or higher.You regain all expended spell slots when you finish a long rest." +
                    "For example, if you know the 1st - level spell cure wounds and have a 1st - level and a 2nd - level spell slot available, you can cast cure wounds using either slot." +
                    "\n\nSpells Known of 1st Level and Higher" +
                    "You know four 1st - level spells of your choice from the bard spell list." +
                    "The Spells Known column of the Bard table shows when you learn more bard spells of your choice. Each of these spells must be of a level for which you have spell slots, as shown on the table.For instance, when you reach 3rd level in this class, you can learn one new spell of 1st or 2nd level." +
                    "Additionally, when you gain a level in this class, you can choose one of the bard spells you know and replace it with another spell from the bard spell list, which also must be of a level for which you have spell slots." +
                    "\n\nSpellcasting Ability" +
                    "\nCharisma is your spellcasting ability for your bard spells.Your magic comes from the heart and soul you pour into the performance of your music or oration.You use your Charisma whenever a spell refers to your spellcasting ability.In addition, you use your Charisma modifier when setting the saving throw DC for a bard spell you cast and when making an attack roll with one." +
                    "\nSpell save DC = 8 + your proficiency bonus + your Charisma modifier" +
                    "\nSpell attack modifier = your proficiency bonus + your Charisma modifier" +
                    "\n\nRitual Casting" +
                    "\nYou can cast any bard spell you know as a ritual if that spell has the ritual tag." +
                    "\n\nSpellcasting Focus" +
                    "\nYou can use a musical instrument (see the Tools section) as a spellcasting focus for your bard spells." +
                    "\n\nBardic Inspiration" +
                    "\nYou can inspire others through stirring words or music.To do so, you use a bonus action on your turn to choose one creature other than yourself within 60 feet of you who can hear you.That creature gains one Bardic Inspiration die, a d6." +
                    "Once within the next 10 minutes, the creature can roll the die and add the number rolled to one ability check, attack roll, or saving throw it makes. The creature can wait until after it rolls the d20 before deciding to use the Bardic Inspiration die, but must decide before the DM says whether the roll succeeds or fails.Once the Bardic Inspiration die is rolled, it is lost.A creature can have only one Bardic Inspiration die at a time." +
                    "You can use this feature a number of times equal to your Charisma modifier (a minimum of once). You regain any expended uses when you finish a long rest." +
                    "Your Bardic Inspiration die changes when you reach certain levels in this class. The die becomes a d8 at 5th level, a d10 at 10th level, and a d12 at 15th level.";
            }

            if (classSelected == "Cleric")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d8 per cleric level" +
                    "\nHit Points at 1st Level: 8 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d8(or 5) + your Constitution modifier per cleric level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: Light armor, medium armor, shields" +
                    "\nWeapons: Simple weapons" +
                    "\nTools: None" +
                    "\nSaving Throws: Wisdom, Charisma" +
                    "\nSkills: Choose two from History, Insight, Medicine, Persuasion, and Religion" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)a mace or(b) a warhammer(if proficient)" +
                    "\n-(a)scale mail, (b)leather armor, or(c) chain mail(if proficient)" +
                    "\n-(a)a light crossbow and 20 bolts or(b) any simple weapon" +
                    "\n-(a) a priest’s pack or(b) an explorer’s pack" +
                    "\n-A shield and a holy symbol" +
                    "\n\nSpellcasting" +
                    "As a conduit for divine power, you can cast cleric spells.See Spells Rules for the general rules of spellcasting and the Spells Listing for the cleric spell list." +
                    "\n\nCantrips" +
                    "\nAt 1st level, you know three cantrips of your choice from the cleric spell list.You learn additional cleric cantrips of your choice at higher levels, as shown in the Cantrips Known column of the Cleric table." +
                    "\n\nPreparing and Casting Spells" +
                    "\nThe Cleric table shows how many spell slots you have to cast your cleric spells of 1st level and higher.To cast one of these spells, you must expend a slot of the spell’s level or higher.You regain all expended spell slots when you finish a long rest." +
                    "You prepare the list of cleric spells that are available for you to cast, choosing from the cleric spell list.When you do so, choose a number of cleric spells equal to your Wisdom modifier + your cleric level(minimum of one spell). The spells must be of a level for which you have spell slots." +
                    "For example, if you are a 3rd - level cleric, you have four 1st - level and two 2nd - level spell slots. With a Wisdom of 16, your list of prepared spells can include six spells of 1st or 2nd level, in any combination. If you prepare the 1st - level spell cure wounds, you can cast it using a 1st - level or 2nd - level slot.Casting the spell doesn’t remove it from your list of prepared spells." +
                    "You can change your list of prepared spells when you finish a long rest. Preparing a new list of cleric spells requires time spent in prayer and meditation: at least 1 minute per spell level for each spell on your list." +
                    "\n\nSpellcasting Ability" +
                    "\nWisdom is your spellcasting ability for your cleric spells.The power of your spells comes from your devotion to your deity.You use your Wisdom whenever a cleric spell refers to your spellcasting ability.In addition, you use your Wisdom modifier when setting the saving throw DC for a cleric spell you cast and when making an attack roll with one." +
                    "\nSpell save DC = 8 + your proficiency bonus + your Wisdom modifier" +
                    "\nSpell attack modifier = your proficiency bonus + your Wisdom modifier" +
                    "\n\nRitual Casting" +
                    "\nYou can cast a cleric spell as a ritual if that spell has the ritual tag and you have the spell prepared." +
                    "\n\nSpellcasting Focus" +
                    "\nYou can use a holy symbol(see the Adventuring Gear section) as a spellcasting focus for your cleric spells." +
                    "\n\nDivine Domain" +
                    "\nChoose one domain related to your deity: Knowledge, Life, Light, Nature, Tempest, Trickery, or War.The Life domain is detailed at the end of the class description and provides examples of gods associated with it.See the Player’s Handbook for details on all the domains.Your choice grants you domain spells and other features when you choose it at 1st level. It also grants you additional ways to use Channel Divinity when you gain that feature at 2nd level, and additional benefits at 6th, 8th, and 17th levels." +
                    "\n\nDomain Spells" +
                    "\nEach domain has a list of spells — its domain spells — that you gain at the cleric levels noted in the domain description.Once you gain a domain spell, you always have it prepared, and it doesn’t count against the number of spells you can prepare each day." +
                    "If you have a domain spell that doesn’t appear on the cleric spell list, the spell is nonetheless a cleric spell for you.";
            }

            if (classSelected == "Druid")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d8 per druid level" +
                    "\nHit Points at 1st Level: 8 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d8(or 5) + your Constitution modifier per druid level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: Light armor, medium armor, shields(druids will not wear armor or use shields made of metal)" +
                    "\nWeapons: Clubs, daggers, darts, javelins, maces, quarterstaffs, scimitars, sickles, slings, spears" +
                    "\nTools: Herbalism kit" +
                    "\nSaving Throws: Intelligence, Wisdom" +
                    "\nSkills: Choose two from Arcana, Animal Handling, Insight, Medicine, Nature, Perception, Religion, and Survival" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)a wooden shield or(b) any simple weapon" +
                    "\n-(a) a scimitar or(b) any simple melee weapon" +
                    "\nLeather armor, an explorer’s pack, and a druidic focus" +
                    "\n\nDruidic" +
                    "\nYou know Druidic, the secret language of druids.You can speak the language and use it to leave hidden messages. You and others who know this language automatically spot such a message. Others spot the message’s presence with a successful DC 15 Wisdom(Perception) check but can’t decipher it without magic." +
                    "\n\nSpellcasting" +
                    "\nDrawing on the divine essence of nature itself, you can cast spells to shape that essence to your will.See Spells Rules for the general rules of spellcasting and the Spells Listing for the druid spell list." +
                    "\n\nCantrips" +
                    "\nAt 1st level, you know two cantrips of your choice from the druid spell list.You learn additional druid cantrips of your choice at higher levels, as shown in the Cantrips Known column of the Druid table." +
                    "\n\nPreparing and Casting Spells" +
                    "\nThe Druid table shows how many spell slots you have to cast your druid spells of 1st level and higher.To cast one of these druid spells, you must expend a slot of the spell’s level or higher.You regain all expended spell slots when you finish a long rest." +
                    "You prepare the list of druid spells that are available for you to cast, choosing from the druid spell list.When you do so, choose a number of druid spells equal to your Wisdom modifier + your druid level(minimum of one spell). The spells must be of a level for which you have spell slots." +
                    "For example, if you are a 3rd - level druid, you have four 1st - level and two 2nd - level spell slots. With a Wisdom of 16, your list of prepared spells can include six spells of 1st or 2nd level, in any combination. If you prepare the 1st - level spell cure wounds, you can cast it using a 1st - level or 2nd - level slot.Casting the spell doesn’t remove it from your list of prepared spells." +
                    "You can also change your list of prepared spells when you finish a long rest. Preparing a new list of druid spells requires time spent in prayer and meditation: at least 1 minute per spell level for each spell on your list." +
                    "\n\nSpellcasting Ability" +
                    "\nWisdom is your spellcasting ability for your druid spells, since your magic draws upon your devotion and attunement to nature.You use your Wisdom whenever a spell refers to your spellcasting ability.In addition, you use your Wisdom modifier when setting the saving throw DC for a druid spell you cast and when making an attack roll with one." +
                    "\nSpell save DC = 8 + your proficiency bonus + your Wisdom modifier" +
                    "\nSpell attack modifier = your proficiency bonus + your Wisdom modifier" +
                    "\n\nRitual Casting" +
                    "\nYou can cast a druid spell as a ritual if that spell has the ritual tag and you have the spell prepared." +
                    "\n\nSpellcasting Focus" +
                    "\nYou can use a druidic focus(see the Adventuring Gear section) as a spellcasting focus for your druid spells.";
            }

            if (classSelected == "Fighter")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d10 per fighter level" +
                    "\nHit Points at 1st Level: 10 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d10(or 6) + your Constitution modifier per fighter level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: All armor, shields" +
                    "\nWeapons: Simple weapons, martial weapons" +
                    "\nTools: None" +
                    "\nSaving Throws: Strength, Constitution" +
                    "\nSkills: Choose two skills from Acrobatics, Animal Handling, Athletics, History, Insight, Intimidation, Perception, and Survival" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)chain mail or(b) leather armor, longbow, and 20 arrows" +
                    "\n-(a) a martial weapon and a shield or(b) two martial weapons" +
                    "\n-(a) a light crossbow and 20 bolts or(b) two handaxes" +
                    "\n-(a) a dungeoneer’s pack or(b) an explorer’s pack" +
                    "\n\nFighting Style" +
                    "\nYou adopt a particular style of fighting as your specialty.Choose one of the following options. You can’t take a Fighting Style option more than once, even if you later get to choose again." +
                    "\n\nArchery" +
                    "\nYou gain a +2 bonus to attack rolls you make with ranged weapons." +
                    "\n\nDefense" +
                    "\nWhile you are wearing armor, you gain a +1 bonus to AC." +
                    "\n\nDueling" +
                    "\nWhen you are wielding a melee weapon in one hand and no other weapons, you gain a +2 bonus to damage rolls with that weapon." +
                    "\n\nGreat Weapon Fighting" +
                    "\nWhen you roll a 1 or 2 on a damage die for an attack you make with a melee weapon that you are wielding with two hands, you can reroll the die and must use the new roll, even if the new roll is a 1 or a 2.The weapon must have the two - handed or versatile property for you to gain this benefit." +
                    "\n\nProtection" +
                    "\nWhen a creature you can see attacks a target other than you that is within 5 feet of you, you can use your reaction to impose disadvantage on the attack roll.You must be wielding a shield." +
                    "\n\nTwo - Weapon Fighting" +
                    "\nWhen you engage in two - weapon fighting, you can add your ability modifier to the damage of the second attack." +
                    "\n\nSecond Wind" +
                    "\nYou have a limited well of stamina that you can draw on to protect yourself from harm.On your turn, you can use a bonus action to regain hit points equal to 1d10 + your fighter level.Once you use this feature, you must finish a short or long rest before you can use it again.";
            }

            if (classSelected == "Monk")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d8 per monk level" +
                    "\nHit Points at 1st Level: 8 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d8(or 5) + your Constitution modifier per monk level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: None" +
                    "\nWeapons: Simple weapons, shortswords" +
                    "\nTools: Choose one type of artisan’s tools or one musical instrument" +
                    "\nSaving Throws: Strength, Dexterity" +
                    "\nSkills: Choose two from Acrobatics, Athletics, History, Insight, Religion, and Stealth" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)a shortsword or(b) any simple weapon" +
                    "\n-(a) a dungeoneer’s pack or(b) an explorer’s pack" +
                    "\n-10 darts" +
                    "\n\nUnarmored Defense" +
                    "\nBeginning at 1st level, while you are wearing no armor and not wielding a shield, your AC equals 10 + your Dexterity modifier +your Wisdom modifier." +
                    "\n\nMartial Arts" +
                    "\nAt 1st level, your practice of martial arts gives you mastery of combat styles that use unarmed strikes and monk weapons, which are shortswords and any simple melee weapons that don’t have the two-handed or heavy property." +
                    "You gain the following benefits while you are unarmed or wielding only monk weapons and you aren’t wearing armor or wielding a shield:" +
                    "\n\n-You can use Dexterity instead of Strength for the attack and damage rolls of your unarmed strikes and monk weapons." +
                    "\n\n-You can roll a d4 in place of the normal damage of your unarmed strike or monk weapon.This die changes as you gain monk levels, as shown in the Martial Arts column of the Monk table." +
                    "\n\n-When you use the Attack action with an unarmed strike or a monk weapon on your turn, you can make one unarmed strike as a bonus action.For example, if you take the Attack action and attack with a quarterstaff, you can also make an unarmed strike as a bonus action, assuming you haven’t already taken a bonus action this turn." +
                    "\n\nCertain monasteries use specialized forms of the monk weapons.For example, you might use a club that is two lengths of wood connected by a short chain(called a nunchaku) or a sickle with a shorter, straighter blade(called a kama).Whatever name you use for a monk weapon, you can use the game statistics provided for the weapon in the Weapons section.";
            }

            if (classSelected == "Paladin")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d10 per paladin level" +
                    "\nHit Points at 1st Level: 10 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d10(or 6) + your Constitution modifier per paladin level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: All armor, shields" +
                    "\nWeapons: Simple weapons, martial weapons" +
                    "\nTools: None" +
                    "\nSaving Throws: Wisdom, Charisma" +
                    "\nSkills: Choose two from Athletics, Insight, Intimidation, Medicine, Persuasion, and Religion" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)a martial weapon and a shield or(b) two martial weapons" +
                    "\n-(a) five javelins or(b) any simple melee weapon" +
                    "\n-(a) a priest’s pack or(b) an explorer’s pack" +
                    "\n-Chain mail and a holy symbol" +
                    "\n\nDivine Sense" +
                    "\nThe presence of strong evil registers on your senses like a noxious odor, and powerful good rings like heavenly music in your ears. As an action, you can open your awareness to detect such forces.Until the end of your next turn, you know the location of any celestial, fiend, or undead within 60 feet of you that is not behind total cover. You know the type(celestial, fiend, or undead) of any being whose presence you sense, but not its identity(the vampire Count Strahd von Zarovich, for instance).Within the same radius, you also detect the presence of any place or object that has been consecrated or desecrated, as with the hallow spell." +
                    "You can use this feature a number of times equal to 1 + your Charisma modifier. When you finish a long rest, you regain all expended uses." +
                    "\n\nLay on Hands" +
                    "\nYour blessed touch can heal wounds.You have a pool of healing power that replenishes when you take a long rest. With that pool, you can restore a total number of hit points equal to your paladin level × 5." +
                    "As an action, you can touch a creature and draw power from the pool to restore a number of hit points to that creature, up to the maximum amount remaining in your pool." +
                    "Alternatively, you can expend 5 hit points from your pool of healing to cure the target of one disease or neutralize one poison affecting it. You can cure multiple diseases and neutralize multiple poisons with a single use of Lay on Hands, expending hit points separately for each one." +
                    "This feature has no effect on undead and constructs.";
            }

            if (classSelected == "Ranger")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d10 per ranger level" +
                    "\nHit Points at 1st Level: 10 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d10(or 6) + your Constitution modifier per ranger level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: Light armor, medium armor, shields" +
                    "\nWeapons: Simple weapons, martial weapons" +
                    "\nTools: None" +
                    "\nSaving Throws: Strength, Dexterity" +
                    "\nSkills: Choose three from Animal Handling, Athletics, Insight, Investigation, Nature, Perception, Stealth, and Survival" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)scale mail or(b) leather armor" +
                    "\n-(a) two shortswords or(b) two simple melee weapons" +
                    "\n-(a) a dungeoneer’s pack or(b) an explorer’s pack" +
                    "\n-A longbow and a quiver of 20 arrows" +
                    "\n\nFavored Enemy" +
                    "\nBeginning at 1st level, you have significant experience studying, tracking, hunting, and even talking to a certain type of enemy." +
                    "Choose a type of favored enemy: aberrations, beasts, celestials, constructs, dragons, elementals, fey, fiends, giants, monstrosities, oozes, plants, or undead. Alternatively, you can select two races of humanoid(such as gnolls and orcs) as favored enemies." +
                    "You have advantage on Wisdom(Survival) checks to track your favored enemies, as well as on Intelligence checks to recall information about them." +
                    "When you gain this feature, you also learn one language of your choice that is spoken by your favored enemies, if they speak one at all." +
                    "You choose one additional favored enemy, as well as an associated language, at 6th and 14th level. As you gain levels, your choices should reflect the types of monsters you have encountered on your adventures." +
                    "\n\nNatural Explorer" +
                    "\nYou are particularly familiar with one type of natural environment and are adept at traveling and surviving in such regions. Choose one type of favored terrain: arctic, coast, desert, forest, grassland, mountain, swamp, or the Underdark.When you make an Intelligence or Wisdom check related to your favored terrain, your proficiency bonus is doubled if you are using a skill that you’re proficient in." +
                    "While traveling for an hour or more in your favored terrain, you gain the following benefits:" +
                    "\n-Difficult terrain doesn’t slow your group’s travel." +
                    "\n-Your group can’t become lost except by magical means." +
                    "\n-Even when you are engaged in another activity while traveling(such as foraging, navigating, or tracking), you remain alert to danger." +
                    "\n-If you are traveling alone, you can move stealthily at a normal pace." +
                    "\n-When you forage, you find twice as much food as you normally would." +
                    "\n-While tracking other creatures, you also learn their exact number, their sizes, and how long ago they passed through the area." +
                    "\n-You choose additional favored terrain types at 6th and 10th level.";
            }

            if (classSelected == "Rogue")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d8 per rogue level" +
                    "\nHit Points at 1st Level: 8 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d8(or 5) + your Constitution modifier per rogue level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: Light armor" +
                    "\nWeapons: Simple weapons, hand crossbows, longswords, rapiers, shortswords" +
                    "\nTools: Thieves’ tools" +
                    "\nSaving Throws: Dexterity, Intelligence" +
                    "\nSkills: Choose four from Acrobatics, Athletics, Deception, Insight, Intimidation, Investigation, Perception, Performance, Persuasion, Sleight of Hand, and Stealth" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)a rapier or(b) a shortsword" +
                    "\n-(a) a shortbow and quiver of 20 arrows or(b) a shortsword" +
                    "\n-(a) a burglar’s pack, (b) a dungeoneer’s pack, or (c) an explorer’s pack" +
                    "\n-Leather armor, two daggers, and thieves’ tools" +
                    "\n\nExpertise" +
                    "\nAt 1st level, choose two of your skill proficiencies, or one of your skill proficiencies and your proficiency with thieves’ tools.Your proficiency bonus is doubled for any ability check you make that uses either of the chosen proficiencies." +
                    "At 6th level, you can choose two more of your proficiencies(in skills or with thieves’ tools) to gain this benefit." +
                    "\n\nSneak Attack" +
                    "\nBeginning at 1st level, you know how to strike subtly and exploit a foe’s distraction.Once per turn, you can deal an extra 1d6 damage to one creature you hit with an attack if you have advantage on the attack roll. The attack must use a finesse or a ranged weapon." +
                    "You don’t need advantage on the attack roll if another enemy of the target is within 5 feet of it, that enemy isn’t incapacitated, and you don’t have disadvantage on the attack roll." +
                    "The amount of the extra damage increases as you gain levels in this class, as shown in the Sneak Attack column of the Rogue table." +
                    "\n\nThieves’ Cant" +
                    "\nDuring your rogue training you learned thieves’ cant, a secret mix of dialect, jargon, and code that allows you to hide messages in seemingly normal conversation.Only another creature that knows thieves’ cant understands such messages. It takes four times longer to convey such a message than it does to speak the same idea plainly." +
                    "In addition, you understand a set of secret signs and symbols used to convey short, simple messages, such as whether an area is dangerous or the territory of a thieves’ guild, whether loot is nearby, or whether the people in an area are easy marks or will provide a safe house for thieves on the run.";
            }

            if (classSelected == "Sorcerer")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d6 per sorcerer level" +
                    "\nHit Points at 1st Level: 6 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d6(or 4) + your Constitution modifier per sorcerer level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: None" +
                    "\nWeapons: Daggers, darts, slings, quarterstaffs, light crossbows" +
                    "\nTools: None" +
                    "\nSaving Throws: Constitution, Charisma" +
                    "\nSkills: Choose two from Arcana, Deception, Insight, Intimidation, Persuasion, and Religion" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)a light crossbow and 20 bolts or(b) any simple weapon" +
                    "\n-(a) a component pouch or(b) an arcane focus" +
                    "\n-(a) a dungeoneer’s pack or(b) an explorer’s pack" +
                    "\n-Two daggers" +
                    "\n\nSpellcasting" +
                    "\nAn event in your past, or in the life of a parent or ancestor, left an indelible mark on you, infusing you with arcane magic. This font of magic, whatever its origin, fuels your spells. See Spells Rules for the general rules of spellcasting and the Spells Listing for the sorcerer spell list." +
                    "\n\nCantrips" +
                    "\nAt 1st level, you know four cantrips of your choice from the sorcerer spell list. You learn additional sorcerer cantrips of your choice at higher levels, as shown in the Cantrips Known column of the Sorcerer table." +
                    "\n\nSpell Slots" +
                    "\nThe Sorcerer table shows how many spell slots you have to cast your sorcerer spells of 1st level and higher. To cast one of these sorcerer spells, you must expend a slot of the spell’s level or higher. You regain all expended spell slots when you finish a long rest." +
                    "For example, if you know the 1st-level spell burning hands and have a 1st-level and a 2nd-level spell slot available, you can cast burning hands using either slot." +
                    "\n\nSpells Known of 1st Level and Higher" +
                    "\nYou know two 1st-level spells of your choice from the sorcerer spell list." +
                    "The Spells Known column of the Sorcerer table shows when you learn more sorcerer spells of your choice.Each of these spells must be of a level for which you have spell slots.For instance, when you reach 3rd level in this class, you can learn one new spell of 1st or 2nd level." +
                    "Additionally, when you gain a level in this class, you can choose one of the sorcerer spells you know and replace it with another spell from the sorcerer spell list, which also must be of a level for which you have spell slots." +
                    "\n\nSpellcasting Ability" +
                    "\nCharisma is your spellcasting ability for your sorcerer spells, since the power of your magic relies on your ability to project your will into the world.You use your Charisma whenever a spell refers to your spellcasting ability.In addition, you use your Charisma modifier when setting the saving throw DC for a sorcerer spell you cast and when making an attack roll with one." +
                    "\nSpell save DC = 8 + your proficiency bonus + your Charisma modifier" +
                    "\nSpell attack modifier = your proficiency bonus + your Charisma modifier" +
                    "\n\nSpellcasting Focus" +
                    "\nYou can use an arcane focus (see the Adventuring Gear section) as a spellcasting focus for your sorcerer spells." +
                    "\n\nSorcerous Origin" +
                    "\nChoose a sorcerous origin, which describes the source of your innate magical power." +
                    "Your choice grants you features when you choose it at 1st level and again at 6th, 14th, and 18th level.";
            }

            if (classSelected == "Warlock")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d8 per warlock level" +
                    "\nHit Points at 1st Level: 8 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d8(or 5) + your Constitution modifier per warlock level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: Light armor" +
                    "\nWeapons: Simple weapons" +
                    "\nTools: None" +
                    "\nSaving Throws: Wisdom, Charisma" +
                    "\nSkills: Choose two skills from Arcana, Deception, History, Intimidation, Investigation, Nature, and Religion" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)a light crossbow and 20 bolts or(b) any simple weapon" +
                    "\n-(a) a component pouch or(b) an arcane focus" +
                    "\n-(a) a scholar’s pack or(b) a dungeoneer’s pack" +
                    "\n-Leather armor, any simple weapon, and two daggers" +
                    "\n\nOtherworldly Patron" +
                    "\nAt 1st level, you have struck a bargain with an otherworldly being of your choice: the Fiend, which is detailed at the end of the class description, or one from another source.Your choice grants you features at 1st level and again at 6th, 10th, and 14th level." +
                    "\n\nPact Magic" +
                    "\nYour arcane research and the magic bestowed on you by your patron have given you facility with spells.See Spells Rules for the general rules of spellcasting and the Spells Listing for the warlock spell list." +
                    "\n\nCantrips" +
                    "\nYou know two cantrips of your choice from the warlock spell list.You learn additional warlock cantrips of your choice at higher levels, as shown in the Cantrips Known column of the Warlock table." +
                    "\n\nSpell Slots" +
                    "\nThe Warlock table shows how many spell slots you have to cast your warlock spells of 1st through 5th level. The table also shows what the level of those slots is; all of your spell slots are the same level.To cast one of your warlock spells of 1st level or higher, you must expend a spell slot.You regain all expended spell slots when you finish a short or long rest." +
                    "For example, when you are 5th level, you have two 3rd-level spell slots.To cast the 1st-level spell witch bolt, you must spend one of those slots, and you cast it as a 3rd-level spell." +
                    "\n\nSpells Known of 1st Level and Higher" +
                    "\nAt 1st level, you know two 1st-level spells of your choice from the warlock spell list." +
                    "The Spells Known column of the Warlock table shows when you learn more warlock spells of your choice of 1st level and higher. A spell you choose must be of a level no higher than what’s shown in the table’s Slot Level column for your level. When you reach 6th level, for example, you learn a new warlock spell, which can be 1st, 2nd, or 3rd level." +
                    "Additionally, when you gain a level in this class, you can choose one of the warlock spells you know and replace it with another spell from the warlock spell list, which also must be of a level for which you have spell slots." +
                    "\n\nSpellcasting Ability" +
                    "\nCharisma is your spellcasting ability for your warlock spells, so you use your Charisma whenever a spell refers to your spellcasting ability.In addition, you use your Charisma modifier when setting the saving throw DC for a warlock spell you cast and when making an attack roll with one." +
                    "\nSpell save DC = 8 + your proficiency bonus + your Charisma modifier" +
                    "\nSpell attack modifier = your proficiency bonus + your Charisma modifier" +
                    "\n\nSpellcasting Focus" +
                    "\nYou can use an arcane focus(see the Adventuring Gear section) as a spellcasting focus for your warlock spells.";
            }

            if (classSelected == "Wizard")
            {
                classInfo = "Hit Points" +
                    "\nHit Dice: 1d6 per wizard level" +
                    "\nHit Points at 1st Level: 6 + your Constitution modifier" +
                    "\nHit Points at Higher Levels: 1d6(or 4) + your Constitution modifier per wizard level after 1st" +
                    "\n\nProficiencies" +
                    "\nArmor: None" +
                    "\nWeapons: Daggers, darts, slings, quarterstaffs, light crossbows" +
                    "\nTools: None" +
                    "\nSaving Throws: Intelligence, Wisdom" +
                    "\nSkills: Choose two from Arcana, History, Insight, Investigation, Medicine, and Religion" +
                    "\n\nEquipment" +
                    "\nYou start with the following equipment, in addition to the equipment granted by your background:" +
                    "\n-(a)a quarterstaff or(b) a dagger" +
                    "\n-(a) a component pouch or(b) an arcane focus" +
                    "\n-(a) a scholar’s pack or(b) an explorer’s pack" +
                    "\n-A spellbook" +
                    "\n\nSpellcasting" +
                    "\nAs a student of arcane magic, you have a spellbook containing spells that show the first glimmerings of your true power.See Spells Rules for the general rules of spellcasting and the Spells Listing for the wizard spell list." +
                    "\n\nCantrips" +
                    "\nAt 1st level, you know three cantrips of your choice from the wizard spell list.You learn additional wizard cantrips of your choice at higher levels, as shown in the Cantrips Known column of the Wizard table." +
                    "\n\nSpellbook" +
                    "\nAt 1st level, you have a spellbook containing six 1st - level wizard spells of your choice.Your spellbook is the repository of the wizard spells you know, except your cantrips, which are fixed in your mind." +
                    "Preparing and Casting Spells" +
                    "The Wizard table shows how many spell slots you have to cast your wizard spells of 1st level and higher. To cast one of these spells, you must expend a slot of the spell’s level or higher. You regain all expended spell slots when you finish a long rest." +
                    "You prepare the list of wizard spells that are available for you to cast.To do so, choose a number of wizard spells from your spellbook equal to your Intelligence modifier +your wizard level(minimum of one spell). The spells must be of a level for which you have spell slots." +
                    "For example, if you’re a 3rd - level wizard, you have four 1st - level and two 2nd - level spell slots. With an Intelligence of 16, your list of prepared spells can include six spells of 1st or 2nd level, in any combination, chosen from your spellbook.If you prepare the 1st - level spell magic missile, you can cast it using a 1st - level or a 2nd - level slot.Casting the spell doesn’t remove it from your list of prepared spells." +
                    "You can change your list of prepared spells when you finish a long rest. Preparing a new list of wizard spells requires time spent studying your spellbook and memorizing the incantations and gestures you must make to cast the spell: at least 1 minute per spell level for each spell on your list." +
                    "\n\nSpellcasting Ability" +
                    "\nIntelligence is your spellcasting ability for your wizard spells, since you learn your spells through dedicated study and memorization.You use your Intelligence whenever a spell refers to your spellcasting ability.In addition, you use your Intelligence modifier when setting the saving throw DC for a wizard spell you cast and when making an attack roll with one." +
                    "\nSpell save DC = 8 + your proficiency bonus + your Intelligence modifier" +
                    "\nSpell attack modifier = your proficiency bonus + your Intelligence modifier" +
                    "\n\nRitual Casting" +
                    "\nYou can cast a wizard spell as a ritual if that spell has the ritual tag and you have the spell in your spellbook. You don’t need to have the spell prepared." +
                    "\n\nSpellcasting Focus" +
                    "\nYou can use an arcane focus(see the Adventuring Gear section) as a spellcasting focus for your wizard spells." +
                    "\n\nLearning Spells of 1st Level and Higher" +
                    "\nEach time you gain a wizard level, you can add two wizard spells of your choice to your spellbook for free.Each of these spells must be of a level for which you have spell slots, as shown on the Wizard table.On your adventures, you might find other spells that you can add to your spellbook(see the “Your Spellbook” sidebar)." +
                    "\n\nYOUR SPELLBOOK" +
                    "\n-The spells that you add to your spellbook as you gain levels reflect the arcane research you conduct on your own, as well as intellectual breakthroughs you have had about the nature of the multiverse.You might find other spells during your adventures.You could discover a spell recorded on a scroll in an evil wizard’s chest, for example, or in a dusty tome in an ancient library." +
                    "\n-Copying a Spell into the Book.When you find a wizard spell of 1st level or higher, you can add it to your spellbook if it is of a spell level you can prepare and if you can spare the time to decipher and copy it." +
                    "Copying that spell into your spellbook involves reproducing the basic form of the spell, then deciphering the unique system of notation used by the wizard who wrote it.You must practice the spell until you understand the sounds or gestures required, then transcribe it into your spellbook using your own notation." +
                    "For each level of the spell, the process takes 2 hours and costs 50 gp.The cost represents material components you expend as you experiment with the spell to master it, as well as the fine inks you need to record it.Once you have spent this time and money, you can prepare the spell just like your other spells." +
                    "\n-Replacing the Book.You can copy a spell from your own spellbook into another book—for example, if you want to make a backup copy of your spellbook.This is just like copying a new spell into your spellbook, but faster and easier, since you understand your own notation and already know how to cast the spell.You need spend only 1 hour and 10 gp for each level of the copied spell." +
                    "If you lose your spellbook, you can use the same procedure to transcribe the spells that you have prepared into a new spellbook.Filling out the remainder of your spellbook requires you to find new spells to do so, as normal.For this reason, many wizards keep backup spellbooks in a safe place." +
                    "\n-The Book’s Appearance. Your spellbook is a unique compilation of spells, with its own decorative flourishes and margin notes. It might be a plain, functional leather volume that you received as a gift from your master, a finely bound gilt - edged tome you found in an ancient library, or even a loose collection of notes scrounged together after you lost your previous spellbook in a mishap." +
                    "\n\nArcane Recovery" +
                    "\nYou have learned to regain some of your magical energy by studying your spellbook. Once per day when you finish a short rest, you can choose expended spell slots to recover.The spell slots can have a combined level that is equal to or less than half your wizard level(rounded up), and none of the slots can be 6th level or higher." +
                    "For example, if you’re a 4th - level wizard, you can recover up to two levels worth of spell slots.You can recover either a 2nd - level spell slot or two 1st - level spell slots.";
            }
        }

    }
}
